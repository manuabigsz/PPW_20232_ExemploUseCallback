import logo from './logo.svg';
import './App.css';
import Pai from './Pai';

function App() {
  return (
    <div>
     <Pai/>
    </div>
  );
}

export default App;
